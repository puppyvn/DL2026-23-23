"""Shared calibration / selective-prediction metrics (Part 2, reused by Part 3 and Part 4).

ECE, ACE and reliability bins are copied verbatim from DeepLearning_Part1.ipynb (Cell 3) so that
all Parts report identical numbers:
  - ECE: 15 equal-width bins (lo, hi]  (Guo et al., 2017)
  - ACE: top-label, 15 equal-mass bins
Confidence = max softmax probability. Every probability is computed in float64.
"""
import numpy as np
from scipy.stats import spearmanr, kendalltau

N_BINS = 15


# ----------------------------------------------------------------------------- probabilities
def softmax_T(logits, T=1.0):
    """softmax(z / T), numerically stable, float64.
    The max is subtracted in the logits' own dtype before casting, exactly like Part 1's softmax_np,
    so at T = 1 the probabilities are bit-identical to Part 1 (same ECE bins and same ACE sort order)."""
    z = np.asarray(logits)
    z = (z - z.max(1, keepdims=True)).astype(np.float64) / T
    e = np.exp(z)
    return e / e.sum(1, keepdims=True)


def log_confidence(logits, T=1.0):
    """log(max softmax(z / T)) = -log sum_j exp((z_j - z_max) / T). Same ordering as confidence,
    but never saturates at 1.0, so it is the score used for ranking."""
    z = np.asarray(logits)
    z = (z - z.max(1, keepdims=True)).astype(np.float64) / T    # same arithmetic order as softmax_T
    e = np.exp(z)
    e[np.arange(len(e)), z.argmax(1)] = 0.0          # drop the max term (== 1) and use log1p on the rest,
    return -np.log1p(e.sum(1))                       # so tiny tails are not lost to 1 + eps == 1


def predict(logits, labels, T=1.0):
    """Per-sample record: prediction, confidence, ranking score and correctness (0/1 float)."""
    p = softmax_T(logits, T)
    pred = p.argmax(1)
    return dict(pred=pred, conf=p.max(1), score=log_confidence(logits, T),
                correct=(pred == np.asarray(labels)).astype(float))


# ----------------------------------------------------------------------------- calibration (identical to Part 1)
def ece_score(conf, correct, n_bins=N_BINS):
    idx = np.digitize(conf, np.linspace(0, 1, n_bins + 1)[1:-1], right=True)      # bins (lo, hi]
    sc = np.bincount(idx, weights=conf, minlength=n_bins)
    sa = np.bincount(idx, weights=correct, minlength=n_bins)
    return np.abs(sa - sc).sum() / len(conf)          # == sum_b (n_b/N)|acc_b - conf_b|


def ace_score(conf, correct, n_bins=N_BINS):
    o = np.argsort(conf, kind="stable"); c = conf[o]; a = correct[o].astype(float)
    return float(np.mean([abs(a[p].mean() - c[p].mean()) for p in np.array_split(np.arange(len(c)), n_bins)]))


def reliability_bins(conf, correct, n_bins=N_BINS):
    """Per equal-width bin: mean confidence, accuracy, count (NaN for empty bins)."""
    idx = np.digitize(conf, np.linspace(0, 1, n_bins + 1)[1:-1], right=True)
    cnt = np.bincount(idx, minlength=n_bins).astype(float)
    with np.errstate(invalid="ignore", divide="ignore"):
        bc = np.bincount(idx, weights=conf, minlength=n_bins) / cnt
        ba = np.bincount(idx, weights=correct, minlength=n_bins) / cnt
    return bc, ba, cnt


def signed_gap(conf, correct):
    """mean confidence - accuracy.  > 0: overconfident, < 0: underconfident."""
    return float(conf.mean() - correct.mean())


def binwise_gap(conf, correct, n_bins=N_BINS):
    """Signed gap (conf - acc) per equal-width bin, with counts. Shows whether the direction is
    the same in every bin, which the global signed gap alone cannot show."""
    bc, ba, cnt = reliability_bins(conf, correct, n_bins)
    return bc - ba, cnt


# ----------------------------------------------------------------------------- selective prediction
def _order(score):
    return np.argsort(-np.asarray(score), kind="stable")          # most confident first


def risk_coverage(score, correct):
    """Accept the k most confident predictions, k = 1..N. Returns (coverage, risk)."""
    err = 1.0 - np.asarray(correct, dtype=float)[_order(score)]
    k = np.arange(1, len(err) + 1)
    return k / len(err), np.cumsum(err) / k


def risk_at(score, correct, coverage):
    """Error rate on the round(coverage * N) most confident predictions."""
    k = int(round(coverage * len(score)))
    return float(1.0 - np.asarray(correct, dtype=float)[_order(score)[:k]].mean())


def oracle_score(correct):
    """Perfect ranking: every correct prediction ranked above every error (lower bound of risk)."""
    return np.asarray(correct, dtype=float)


def aurc(score, correct):
    """Area under the risk-coverage curve (secondary number only; never read alone)."""
    return float(risk_coverage(score, correct)[1].mean())


def e_aurc(score, correct):
    """AURC minus the oracle AURC at the same accuracy: isolates ranking quality from accuracy."""
    return aurc(score, correct) - aurc(oracle_score(correct), correct)


# ----------------------------------------------------------------------------- ranking agreement
def topk_overlap(score_a, score_b, frac):
    """|top-frac set under a  ∩  top-frac set under b| / size of the set."""
    k = int(round(frac * len(score_a)))
    return len(np.intersect1d(_order(score_a)[:k], _order(score_b)[:k])) / k


def ranking_agreement(score_ref, score, fracs=(0.8, 0.6)):
    out = dict(spearman=float(spearmanr(score_ref, score).statistic),
               kendall=float(kendalltau(score_ref, score).statistic))
    for f in fracs:
        out[f"overlap_top{int(round(100 * f))}"] = topk_overlap(score_ref, score, f)
    return out


# ----------------------------------------------------------------------------- bootstrap
DEFAULT_METRICS = {
    "acc":    lambda r: r["correct"].mean(),
    "conf":   lambda r: r["conf"].mean(),
    "gap":    lambda r: signed_gap(r["conf"], r["correct"]),
    "ece":    lambda r: ece_score(r["conf"], r["correct"]),
    "ace":    lambda r: ace_score(r["conf"], r["correct"]),
    "risk80": lambda r: risk_at(r["score"], r["correct"], 0.8),
    "risk60": lambda r: risk_at(r["score"], r["correct"], 0.6),
}


def paired_bootstrap(records, metrics=None, B=1000, seed=0):
    """Resample the test set B times; the SAME indices are used for every record in each draw,
    so differences between records (e.g. T=0.5 minus T=1) get valid paired CIs.
    Returns {record_name: {metric: array(B)}}."""
    metrics = metrics or DEFAULT_METRICS
    rng = np.random.default_rng(seed)
    N = len(next(iter(records.values()))["correct"])
    out = {n: {m: np.empty(B) for m in metrics} for n in records}
    for b in range(B):
        idx = rng.integers(0, N, N)
        for n, r in records.items():
            sub = {k: v[idx] for k, v in r.items()}
            for m, fn in metrics.items():
                out[n][m][b] = fn(sub)
    return out


def ci(samples, level=95):
    lo, hi = np.percentile(samples, [(100 - level) / 2, 100 - (100 - level) / 2])
    return float(lo), float(hi)


# ----------------------------------------------------------------------------- team figure style (I5, see STYLE.md)
# Palette and typography taken from the team report (tailieuchinh/main.pdf): bold figure titles, white
# background, light grid, and the six series colours sampled from its figures.
PAL = {"green": "#1b7837", "blue": "#2166ac", "dark": "#333333", "orange": "#d6600a", "red": "#c0392b",
       "purple": "#6a3d9a", "gray": "#8c8c8c"}
RC_PARAMS = {"figure.dpi": 110, "axes.grid": True, "grid.alpha": .25, "font.size": 10,
             "font.family": "DejaVu Sans", "savefig.dpi": 150, "savefig.bbox": "tight",
             "figure.titlesize": 13, "figure.titleweight": "bold", "axes.titlesize": 11,
             "axes.edgecolor": "black", "legend.fontsize": 8, "legend.framealpha": .9,
             "errorbar.capsize": 4,
             "axes.prop_cycle": __import__("cycler").cycler(color=[PAL[k] for k in ("blue", "orange", "green", "red", "purple", "dark")])}
C = {  # semantic colours shared by every Part (reliability colours as rendered in main.pdf)
    "acc": "#1f77b4", "over": "#f1b3b4", "over_edge": "#c0392b", "under": "#238584", "under_edge": "#1b5e5d",
    "over_area": PAL["red"], "under_area": PAL["blue"],          # filled gap areas in the line-style reliability plot
    "diag": "black", "oracle": PAL["green"], "random": PAL["gray"],
    "correct": "#1f77b4", "wrong": "#d62728"}                     # confidence histograms, as in main.pdf
FAMILY_COLOR = {"LeNet": PAL["dark"], "VGG": PAL["orange"], "ResNet": PAL["blue"], "DenseNet": PAL["green"]}   # Part 1
T_COLOR = {0.5: PAL["red"], 1.0: PAL["dark"], 2.0: PAL["blue"]}                                                # Part 2
T_MARKER = {0.5: ">", 1.0: "o", 2.0: "<"}       # Part 2: shape as a second encoding, so T is never told by colour alone
METHOD_COLOR = {"Uncalibrated": PAL["dark"], "Temperature Scaling": PAL["orange"], "Dirichlet": PAL["green"]}  # Part 4


def shades(hex_color, n, lo=.35, hi=1.0):
    """n shades of one hue, light to dark (mixed with white), for ordered series such as noise levels."""
    rgb = np.array([int(hex_color[i:i + 2], 16) for i in (1, 3, 5)]) / 255
    return [tuple(1 - a * (1 - rgb)) for a in np.linspace(lo, hi, n)]


def severity_color(s):
    """Part 3: clean (s = 0) is black, severity 1..5 go from light to dark purple."""
    import matplotlib.pyplot as plt
    return "black" if s == 0 else plt.get_cmap("Purples")(0.35 + 0.15 * (s - 1))


def apply_style():
    import matplotlib.pyplot as plt
    plt.rcParams.update(RC_PARAMS)


def fig_name(part, content, variant=None, ext="png"):
    """fig_p{part}_{content}[_{variant}].png, e.g. fig_name(3, "reliability", "gaussian_noise")."""
    return f"fig_p{part}_{content}" + (f"_{variant}" if variant else "") + f".{ext}"


def table_name(part, content, ext="csv"):
    return f"p{part}_{content}.{ext}"


# ----------------------------------------------------------------------------- plotting
def plot_reliability(ax, conf, correct, n_bins=N_BINS, title=None):
    """Bar reliability diagram in the main.pdf style: blue = accuracy, pink = overconfidence gap (bar below y = x),
    teal = underconfidence gap (bar above y = x). Colours are opaque, so the legend shows exactly what is drawn."""
    bc, ba, cnt = reliability_bins(conf, correct, n_bins)
    w = 1 / n_bins; centers = (np.arange(n_bins) + .5) * w; ok = cnt > 0
    ax.bar(centers[ok], ba[ok], width=w * .95, color=C["acc"], edgecolor="k", lw=.4, label="accuracy in bin")
    ax.bar(centers[ok], np.where(bc[ok] > ba[ok], bc[ok] - ba[ok], 0), bottom=ba[ok], width=w * .95,
           color=C["over"], edgecolor="white", lw=.4, label="over-conf gap (conf > acc)")
    ax.bar(centers[ok], np.where(ba[ok] > bc[ok], ba[ok] - bc[ok], 0), bottom=bc[ok], width=w * .95,
           color=C["under"], edgecolor="white", lw=.4, label="under-conf gap (acc > conf)")
    ax.plot(bc[ok], ba[ok], "o", color="k", ms=3, label="(mean conf, acc) of bin")
    ax.plot([0, 1], [0, 1], "--", color=C["diag"], lw=1, label="y = x")
    ax.set_xlim(0, 1); ax.set_ylim(0, 1); ax.set_xlabel("confidence"); ax.set_ylabel("accuracy")
    if title: ax.set_title(title, fontsize=9)


def plot_reliability_curve(ax, conf, correct, color=None, marker="o", label=None, n_bins=N_BINS, min_count=10, shade=True):
    """Simpler reading of a reliability diagram: one line through (mean confidence, accuracy) of each bin, dot size
    = number of samples, and the gap to y = x filled red where the model is overconfident (below the line) and blue
    where it is underconfident (above). Bins with fewer than `min_count` samples are left out of the line (too noisy);
    plot_bin_counts shows how many samples every bin holds."""
    bc, ba, cnt = reliability_bins(conf, correct, n_bins)
    ok = cnt >= min_count
    x, y, n = bc[ok], ba[ok], cnt[ok]
    color = color or C["acc"]
    if shade:
        ax.fill_between(x, y, x, where=y <= x, interpolate=True, color=C["over_area"], alpha=.25, lw=0, label="overconfident gap (acc < conf)")
        ax.fill_between(x, y, x, where=y >= x, interpolate=True, color=C["under_area"], alpha=.25, lw=0, label="underconfident gap (acc > conf)")
    ax.plot([0, 1], [0, 1], "--", color=C["diag"], lw=1, label="perfect calibration (y = x)")
    ax.plot(x, y, "-", color=color, lw=1.8, zorder=3)
    ax.scatter(x, y, s=12 + 160 * np.sqrt(n / len(conf)), marker=marker, color=color, edgecolor="white", lw=.8, zorder=4, label=label)
    ax.set_xlim(0, 1.03); ax.set_ylim(0, 1.04)          # a little room so dots at confidence/accuracy ~1 are not clipped
    ax.set_xlabel("confidence (mean in bin)"); ax.set_ylabel("accuracy in bin")


def plot_bin_counts(ax, conf, n_bins=N_BINS):
    """Number of samples per reliability bin (log scale)."""
    _, _, cnt = reliability_bins(conf, np.zeros_like(conf), n_bins)
    w = 1 / n_bins; centers = (np.arange(n_bins) + .5) * w
    ax.bar(centers, np.maximum(cnt, 0), width=w * .95, color=PAL["gray"], edgecolor="k", lw=.4)
    ax.set_yscale("log"); ax.set_xlim(0, 1.03); ax.set_ylim(0.8, len(conf) * 15)     # headroom for the count labels
    ax.set_xlabel("confidence"); ax.set_ylabel("# samples (log)")
    for c, n in zip(centers, cnt):
        if n > 0: ax.text(c, n * 1.15, f"{int(n)}", ha="center", va="bottom", fontsize=6, rotation=90)


def plot_risk_coverage(ax, score, correct, **kw):
    cov, risk = risk_coverage(score, correct)
    ax.plot(cov, risk, **kw)
    ax.set_xlabel("coverage (fraction of predictions accepted)"); ax.set_ylabel("risk (error rate on accepted)")
    ax.set_xlim(0, 1)
