"""Sanity tests for calib_metrics on synthetic data with known answers.  Run: python test_calib_metrics.py"""
import numpy as np
import calib_metrics as cm

rng = np.random.default_rng(0)

# 1) calibrated by construction -> ECE, ACE, gap ~ 0  (same test as Part 1)
c = rng.uniform(.5, 1, 50000); k = (rng.uniform(size=50000) < c).astype(float)
assert cm.ece_score(c, k) < 0.01 and cm.ace_score(c, k) < 0.02 and abs(cm.signed_gap(c, k)) < 0.01

# 2) overconfident by 0.15 -> ECE ~ ACE ~ gap ~ +0.15, every non-empty bin has a positive gap
k2 = (rng.uniform(size=50000) < c - .15).astype(float)
assert abs(cm.ece_score(c, k2) - .15) < .02 and abs(cm.ace_score(c, k2) - .15) < .02
assert abs(cm.signed_gap(c, k2) - .15) < .01
g, n = cm.binwise_gap(c, k2); assert (g[n > 100] > 0).all()

# 3) underconfident -> negative gap
k3 = (rng.uniform(size=50000) < np.minimum(c + .1, 1)).astype(float)
assert cm.signed_gap(c, k3) < -.05

# 4) softmax_T / log_confidence: rows sum to 1, log_confidence == log(max prob), argmax independent of T
z = rng.normal(0, 3, (2000, 10)); y = rng.integers(0, 10, 2000)
for T in (0.25, 0.5, 1, 2, 4):
    p = cm.softmax_T(z, T)
    assert np.allclose(p.sum(1), 1) and np.allclose(np.log(p.max(1)), cm.log_confidence(z, T))
    assert (p.argmax(1) == z.argmax(1)).all()
# per-sample confidence strictly decreases with T (non-tied logits)
assert (cm.softmax_T(z, .5).max(1) > cm.softmax_T(z, 1).max(1)).all()
assert (cm.softmax_T(z, 1).max(1) > cm.softmax_T(z, 2).max(1)).all()
# log_confidence keeps the order where float64 softmax saturates to exactly 1.0
big = np.zeros((2, 10)); big[:, 0] = [40, 45]                     # margins 80 and 90 at T = 0.5
assert (cm.softmax_T(big, .5).max(1) == 1.0).all()                 # both saturate -> tie
lc = cm.log_confidence(big, .5)
assert (lc < 0).all() and lc[1] > lc[0]                            # still strictly ordered

# 5) risk-coverage: full coverage risk = error rate; oracle risk = 0 until coverage = accuracy
corr = (rng.uniform(size=10000) < .9).astype(float); s = rng.normal(size=10000)
cov, risk = cm.risk_coverage(s, corr)
assert np.isclose(risk[-1], 1 - corr.mean()) and np.isclose(cov[-1], 1)
assert np.isclose(cm.risk_at(s, corr, 1.0), 1 - corr.mean())
cov_o, risk_o = cm.risk_coverage(cm.oracle_score(corr), corr)
assert (risk_o[cov_o <= corr.mean() - 1e-9] == 0).all()
assert np.isclose(cm.e_aurc(cm.oracle_score(corr), corr), 0)
# random score: risk roughly flat at the error rate
assert abs(cm.risk_at(s, corr, .5) - (1 - corr.mean())) < .02
# risk_at uses round(coverage * N) most confident
assert np.isclose(cm.risk_at(np.arange(10.), np.array([0, 0, 1, 1, 1, 1, 1, 1, 1, 1.]), .8), 0)

# 6) ranking agreement: identical -> 1; monotone transform -> 1; reversed -> -1, overlap of top-80 = 0.75
r = cm.ranking_agreement(s, s); assert np.isclose(r["spearman"], 1) and r["overlap_top80"] == 1
r = cm.ranking_agreement(s, np.exp(s)); assert np.isclose(r["spearman"], 1)
r = cm.ranking_agreement(s, -s); assert np.isclose(r["spearman"], -1) and np.isclose(r["overlap_top80"], .75)

# 7) paired bootstrap: same indices across records -> difference of a record with itself is exactly 0
rec = cm.predict(z, y, 1.0)
bs = cm.paired_bootstrap({"a": rec, "b": dict(rec)}, B=50, seed=1)
assert all(np.array_equal(bs["a"][m], bs["b"][m]) for m in bs["a"])
lo, hi = cm.ci(bs["a"]["acc"]); assert lo <= rec["correct"].mean() <= hi

print("all calib_metrics tests passed")
